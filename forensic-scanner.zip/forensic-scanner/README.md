# Форензик-сканер (Forensic Scanner)

Десктопная программа для локального анализа системы пользователя на наличие признаков использования читов и запрещённых модификаций.

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![Platform](https://img.shields.io/badge/platform-Windows%20x64-lightgrey.svg)
![Language](https://img.shields.io/badge/language-C%2B%2B17-orange.svg)

## 📋 Описание

Программа выполняет комплексный анализ системы:

- **Анализ хешей файлов** - проверка файлов в системных директориях на совпадение с базой известных читов
- **Проверка истории браузеров** - поиск посещений подозрительных сайтов и ключевых слов
- **Анализ Discord** - проверка локальных данных Discord на связи с читерскими сообществами
- **Расчёт риска** - итоговая оценка риска с цветовой индикацией

## 🎨 Интерфейс

### Главный экран
- Индикатор риска (0-100%) с цветовой шкалой:
  - 🟢 Зелёный (0-20%) - низкий риск
  - 💛 Жёлтый (21-50%) - средний риск
  - 🟠 Оранжевый (51-70%) - высокий риск
  - 🔴 Красный (>70%) - критический риск
- Сводка по категориям триггеров
- Три вкладки с подробными логами

### Логи
- **Лог хешей** - найденные совпадения с базой хешей
- **Лог браузера** - обнаруженные ключевые слова и сайты
- **Лог Discord** - найденные упоминания серверов/каналов

## 🏗️ Структура проекта

```
forensic-scanner/
├── include/                    # Заголовочные файлы
│   ├── Config.h               # Конфигурация
│   ├── Logger.h               # Логирование
│   ├── HashScanner.h          # Анализ хешей
│   ├── BrowserScanner.h       # Анализ браузеров
│   ├── DiscordScanner.h       # Анализ Discord
│   ├── RiskCalculator.h       # Расчёт риска
│   └── MainWindow.h           # GUI
├── src/                       # Исходные файлы
│   ├── main.cpp              # Точка входа
│   ├── Config.cpp
│   ├── Logger.cpp
│   ├── HashScanner.cpp
│   ├── BrowserScanner.cpp
│   ├── DiscordScanner.cpp
│   ├── RiskCalculator.cpp
│   └── UI/
│       └── MainWindow.cpp    # Реализация GUI
├── libs/
│   └── imgui/                # Библиотека ImGui
├── config/                   # Конфигурационные файлы
│   ├── keywords.txt          # Ключевые слова
│   ├── blacklist_sites.txt   # Чёрный список сайтов
│   ├── discord_blacklist.txt # Чёрный список Discord
│   └── hash_database.txt     # База хешей
├── build/                    # Директория сборки
├── CMakeLists.txt           # Файл сборки CMake
└── README.md                # Этот файл
```

## 🔧 Требования для сборки

- **ОС**: Windows 10/11 x64
- **Компилятор**: Visual Studio 2019/2022 с C++17
- **CMake**: версия 3.16 или выше
- **DirectX 11 SDK** (обычно включён в Windows SDK)

## 📦 Зависимости

### ImGui (обязательно)
Скачайте ImGui с официального репозитория:

```bash
git clone https://github.com/ocornut/imgui.git
```

Скопируйте следующие файлы в `libs/imgui/`:
- `imgui.cpp`
- `imgui.h`
- `imgui_demo.cpp`
- `imgui_draw.cpp`
- `imgui_internal.h`
- `imgui_tables.cpp`
- `imgui_widgets.cpp`
- `imconfig.h`
- `imstb_rectpack.h`
- `imstb_textedit.h`
- `imstb_truetype.h`

Из папки `backends/` скопируйте:
- `imgui_impl_win32.cpp`
- `imgui_impl_win32.h`
- `imgui_impl_dx11.cpp`
- `imgui_impl_dx11.h`

## 🛠️ Инструкция по сборке

### Способ 1: CMake + Visual Studio

```bash
# 1. Перейдите в директорию проекта
cd forensic-scanner

# 2. Создайте директорию сборки
mkdir build
cd build

# 3. Сгенерируйте проект Visual Studio
cmake .. -G "Visual Studio 17 2022" -A x64

# 4. Соберите проект
cmake --build . --config Release

# Или откройте ForensicScanner.sln в Visual Studio и соберите
```

### Способ 2: Visual Studio напрямую

1. Откройте Visual Studio
2. Выберите "Открыть папку" и укажите директорию `forensic-scanner`
3. Visual Studio автоматически распознает CMakeLists.txt
4. Выберите конфигурацию Release x64
5. Нажмите "Сборка" → "Собрать всё"

### Способ 3: Developer Command Prompt

```bash
# Откройте Developer Command Prompt for VS 2022

cd forensic-scanner
mkdir build
cd build
cmake .. -G "NMake Makefiles" -DCMAKE_BUILD_TYPE=Release
nmake
```

## 📁 После сборки

После успешной сборки в директории `build/Release/` (или `build/`) появится:
- `ForensicScanner.exe` - исполняемый файл
- `config/` - директория с конфигурационными файлами

## ⚙️ Конфигурация

### keywords.txt
Список ключевых слов для поиска в браузере и Discord.
```
# Пример
cheat
hack
inject
```

### blacklist_sites.txt
Список доменов сайтов, связанных с читами.
```
# Пример
unknowncheats.me
mpgh.net
```

### discord_blacklist.txt
Названия серверов и каналов Discord для поиска.
```
# Пример
cheat-server
hvh-community
```

### hash_database.txt
База хешей запрещённого ПО.
```
# Формат: hash|category|description|weight
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855|cheats|Cheat name|40
```

## 🚀 Запуск

1. Запустите `ForensicScanner.exe`
2. Нажмите кнопку "ЗАПУСТИТЬ СКАНИРОВАНИЕ"
3. Дождитесь завершения сканирования
4. Просмотрите результаты на вкладках логов

## 📊 Расчёт риска

| Категория | Вес по умолчанию | Макс. вклад |
|-----------|------------------|-------------|
| Совпадение хеша | 40% | 50% |
| Ключевое слово в браузере | 15% | 30% |
| Посещение сайта | 20% | 30% |
| Совпадение в Discord | 25% | 30% |

## 📝 Логирование

Все результаты сканирования записываются в файл `scan_log.txt` в директории программы.

## ⚠️ Важно

- Программа работает **только на чтение** - никакие файлы не модифицируются и не удаляются
- Для полноценной работы требуются **права администратора** (для доступа к некоторым системным директориям)
- Результаты носят **рекомендательный характер** и требуют дополнительной проверки

## 🔒 Безопасность

- Программа не отправляет данные в интернет
- Все операции выполняются локально
- Исходный код открыт для аудита

## 📄 Лицензия

MIT License

## 🤝 Разработка

Для добавления новых правил обнаружения:

1. **Новые хеши**: Добавьте в `config/hash_database.txt`
2. **Новые ключевые слова**: Добавьте в `config/keywords.txt`
3. **Новые сайты**: Добавьте в `config/blacklist_sites.txt`
4. **Новые Discord серверы**: Добавьте в `config/discord_blacklist.txt`

---

**Версия**: 1.0.0  
**Платформа**: Windows x64  
**Язык**: C++17
